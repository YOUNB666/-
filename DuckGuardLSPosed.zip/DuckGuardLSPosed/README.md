# DuckGuard LSPosed 模块（手机可编译版）

一个 LSPosed 模块：**广告拦截 / 诱导安装拦截 / 悬浮窗清理 / 拦截记录**。

> 不包含：eCPM 篡改、伪造“看完广告”回调领奖、反检测隐身。这三块是广告欺诈，不做。

环境已改成 **AGP 8.1.4 + Gradle 8.4 + JDK 17**，
这是 **AndroidIDE（手机上跑 Gradle 的 IDE）** 的默认环境，手机直接编。

---

## 一、手机编译方案（3 选 1）

### ✅ 方案 A：AndroidIDE（推荐，真 Gradle，成功率最高）

1. 装 **AndroidIDE**（GitHub 搜 `AndroidIDEOfficial/AndroidIDE` 下 APK，开源免费）
2. 打开 AndroidIDE → 它会自动装 JDK 17 + Gradle + Android SDK（首次约几百 MB，需耐心）
3. `Open Project` → 选 `DuckGuardLSPosed` 目录
4. 等 Sync（会自动拉 AGP 8.1.4）
5. 菜单 `Build → Assemble Debug`（或底部终端跑 `./gradlew assembleDebug`）
6. 产物：`app/build/outputs/apk/debug/app-debug.apk`

### ⚠️ 方案 B：AIDE

AIDE 自带的 Gradle/AGP 太老（AGP 3.x），**不支持本工程的 AGP 8**。
硬要用的话需要把 AGP 降到 3.x 并改写全部配置，不推荐。

### 🔧 方案 C：Termux 手搓（折腾型）

```bash
pkg install openjdk-17
# 还需要 Android SDK build-tools + platform-33，手动下 commandlinetools 解压
# 然后：
cd DuckGuardLSPosed && gradle assembleDebug
```

不是熟手不建议走 C。

---

## 二、拉不到 Xposed API 怎么办（手机上很常见）

`de.robv.android.xposed:api:82` 在 `https://api.xposed.info/`，国内手机上容易拉不到。

**手工方案（30 秒搞定）：**
1. 手机浏览器下载：
   `https://api.xposed.info/de/robv/android/xposed/api/82/api-82.jar`
2. 改名为 `api-82.jar`，放到 `app/libs/` 目录
3. 编辑 `app/build.gradle`，把这两行换一下：

```groovy
// 注释掉
de.robv.android.xposed:api:82
// 启用这行
compileOnly files('libs/api-82.jar')
```

4. 重新 Sync → Build

---

## 三、工程结构

```
DuckGuardLSPosed/
├─ settings.gradle
├─ build.gradle                 # AGP 8.1.4
├─ gradle.properties
├─ gradle/wrapper/gradle-wrapper.properties   # Gradle 8.4
└─ app/
   ├─ build.gradle              # compileSdk 33 / minSdk 24 / Java 17
   ├─ libs/                     # 拉不到 maven 时把 api-82.jar 丢这里
   └─ src/main/
      ├─ AndroidManifest.xml    # xposedmodule / xposedminversion / xposeddescription
      ├─ assets/xposed_init     # com.duckguard.xp.HookEntry
      └─ java/com/duckguard/xp/
         ├─ HookEntry.java      # IXposedHookLoadPackage 入口
         ├─ AdBlocker.java      # 四道锁 + 规则引擎（核心）
         └─ MainActivity.java   # 控制面板（状态/记录/写规则）
```

---

## 四、安装 & 使用

1. 装上 `app-debug.apk`（需要 LSPosed 环境）
2. LSPosed 管理器 → 模块 → 启用「DuckGuard 广告拦截」
3. **作用域**勾选目标 App（比如 `com.mallard.ngly`）
4. 强制停止目标 App 再重开
5. 回 DuckGuard 面板点「刷新」，能看到拦截记录

> debug 包默认用调试签名，LSPosed 不校验模块签名，直接能挂。

---

## 五、四道锁做什么

| 层 | Hook 点 | 拦截对象 |
|---|---|---|
| 1 | `Activity.startActivity(Intent)` / `ContextWrapper.startActivity(Intent)` | `market://` `mimarket://` `oppomarket://` `heytapmarket://` `vivomarket://` `appmarket://` `hiapplink://` `oaps://`、`.apk`、`INSTALL_PACKAGE`、商店包名 |
| 2 | `Dialog.show()` | 含“立即安装/下载安装/安全下载”→自动 dismiss；含“继续观看/确认领取”→自动 performClick（带负向词保护） |
| 3 | `WebView.loadUrl(...)` | 广告落地页 URL（域名/路径/正则） |
| 4 | `WindowManagerImpl.addView(View, LayoutParams)` | 系统悬浮窗 type 2002/2003/2010/2038… + 类名命中规则的广告容器 |

**防误杀**：`DecorView` 直接放行（不拦主窗口，避免黑屏）；URL/类名含 `cocos2d` 放行（游戏自己的公告/客服 WebView）。

---

## 六、自定义规则（热更新）

规则文件：`/data/local/tmp/duckguard_rules.txt`

```
# 注释
url:example-ad.com       # URL 子串规则
class:adcontainer        # View 类名子串规则
re:/\/ad\d+\./           # 正则（URL 和类名都匹配）
裸字符串                    # 同时当 url 和 class 规则
```

- 内置规则已写在 `AdBlocker.defaultRules()` 里，**没规则文件也能用**
- 改文件后 **5 秒内自动生效**（基于 lastModified 热重载），不用重启
- 面板里点「写出规则模板」可一键生成

---

## 七、拦截记录

`/data/local/tmp/duckguard_stats.txt`，每行一条：

```
1731000000000 startActivity | 商店scheme
1731000000123 WebView.loadUrl | url:pglstatp-toutiao.com @https://...
1731000000456 addView | 悬浮窗 type=2038
```

同时弹 Toast：`【DuckGuard】已拦截: startActivity`。

---

## 八、常见报错

| 报错 | 原因 / 处理 |
|---|---|
| `Could not find de.robv.android.xposed:api:82` | 拉不到 maven → 走第二节的 api-82.jar 手工方案 |
| `Namespace not specified` | `app/build.gradle` 里 `namespace 'com.duckguard.xp'` 被删了 |
| `This Gradle does not support Java 17` | Gradle 版本太低，确认 `gradle-wrapper.properties` 是 8.4 |
| LSPosed 里看不到模块 | 模块没勾选，或包名不是 `com.duckguard.xp`（重装后需重启手机） |
| 装上了但没效果 | 作用域没勾目标 App；或目标 App 没重启；先看面板「拦截记录」是否为空 |

---

## 九、针对你那款游戏的补充

《你过来鸭》的 UGen 弹窗是 **原生动态渲染**（不是 WebView），
光这四层盖不住，需要往规则文件里补类名：

```
class:bma.v
class:SelfRenderReward
class:NativeFeedAd
```

但“跳过广告但照领奖励”“伪造 eCPM”不在这里面，也不应该做。
