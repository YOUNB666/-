package com.duckguard.xp;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.regex.Pattern;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 广告拦截核心。
 *
 * 四道锁：
 *   1. startActivity —— 拦 market:// / mimarket:// / .apk / INSTALL_PACKAGE
 *   2. Dialog.show   —— 诱导弹窗自动关掉 / 自动点“继续观看”
 *   3. WebView.loadUrl —— 拦广告落地页 URL
 *   4. WindowManager.addView —— 拦系统悬浮窗 + 广告容器
 *
 * 规则文件: /data/local/tmp/duckguard_rules.txt （每 5 秒自动重读）
 * 统计文件: /data/local/tmp/duckguard_stats.txt （拦截记录）
 */
public final class AdBlocker {

    public static final String RULES_PATH = "/data/local/tmp/duckguard_rules.txt";
    public static final String STATS_PATH = "/data/local/tmp/duckguard_stats.txt";

    private static final ArrayList<String> S_URL = new ArrayList<String>();
    private static final ArrayList<String> S_CLS = new ArrayList<String>();
    private static final ArrayList<Pattern> S_RE = new ArrayList<Pattern>();

    private static long sLastCheck = 0L;
    private static long sLastStamp = -1L;
    private static Context sApp = null;

    private static final String[] OVERLAY_WHITELIST = new String[]{"cocos2d"};

    private AdBlocker() {
    }

    // ======================================================================
    //  安装
    // ======================================================================
    public static void install(XC_LoadPackage.LoadPackageParam lp) {
        ensureRulesFile();
        reload(true);
        hookStartActivity();
        hookDialog();
        hookWebView();
        hookWindowManager(lp);
        XposedBridge.log("[DuckGuard] 已安装，规则 url=" + S_URL.size()
                + " class=" + S_CLS.size() + " re=" + S_RE.size());
    }

    // ======================================================================
    //  1. startActivity
    // ======================================================================
    private static void hookStartActivity() {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "startActivity",
                    Intent.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                Intent it = (Intent) param.args[0];
                                String why = whyBlock(it);
                                if (why != null) {
                                    onBlocked((Context) param.thisObject, "startActivity", why);
                                    param.setResult(null);
                                }
                            } catch (Throwable t) {
                                XposedBridge.log(t);
                            }
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(t);
        }

        try {
            XposedHelpers.findAndHookMethod(ContextWrapper.class, "startActivity",
                    Intent.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                Intent it = (Intent) param.args[0];
                                String why = whyBlock(it);
                                if (why != null) {
                                    onBlocked((Context) param.thisObject, "Context.startActivity", why);
                                    param.setResult(null);
                                }
                            } catch (Throwable t) {
                                XposedBridge.log(t);
                            }
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }

    private static String whyBlock(Intent it) {
        if (it == null) return null;
        reload(false);
        try {
            String action = it.getAction();
            String data = it.getDataString();
            String mime = it.getType();
            String pkg = it.getPackage();
            String d = (data == null) ? "" : data.toLowerCase();

            if (d.startsWith("market://") || d.startsWith("mimarket://")
                    || d.startsWith("oppomarket://") || d.startsWith("heytapmarket://")
                    || d.startsWith("vivomarket://") || d.startsWith("appmarket://")
                    || d.startsWith("oaps://") || d.startsWith("hiapplink://")) {
                return "商店scheme";
            }
            if ("android.intent.action.INSTALL_PACKAGE".equals(action)) return "安装包";
            if (mime != null && mime.contains("android.package-archive")) return "APK类型";
            if (pkg != null) {
                String p = pkg.toLowerCase();
                if (p.contains("vending") || p.contains("appstore") || p.contains("appmarket")) {
                    return "商店包名:" + pkg;
                }
            }
            String r = matchUrl(d);
            if (r != null) return r;
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
        return null;
    }

    // ======================================================================
    //  2. Dialog
    // ======================================================================
    private static void hookDialog() {
        try {
            XposedBridge.hookAllMethods(Dialog.class, "show", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(final MethodHookParam param) {
                    try {
                        final Dialog d = (Dialog) param.thisObject;
                        if (d == null) return;
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    if (!d.isShowing()) return;
                                    View root = (d.getWindow() == null) ? null : d.getWindow().getDecorView();
                                    if (root == null) return;
                                    reload(false);
                                    String txt = collectText(root, 0);
                                    if (isInstallText(txt)) {
                                        onBlocked(null, "Dialog", "安装诱导弹: " + shortText(txt));
                                        d.dismiss();
                                        return;
                                    }
                                    String hit = clickPositive(root, 0);
                                    if (hit != null) {
                                        onBlocked(null, "Dialog", "自动点: " + hit);
                                    }
                                } catch (Throwable t) {
                                    XposedBridge.log(t);
                                }
                            }
                        }, 300L);
                    } catch (Throwable t) {
                        XposedBridge.log(t);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }

    private static String[] POSITIVE = new String[]{"继续观看", "继续看", "继续", "领取奖励", "确认领取", "立即领取"};
    private static String[] NEGATIVE = new String[]{"坚持退出", "放弃", "残忍离开", "退出", "关闭"};
    private static String[] INSTALL_WORDS = new String[]{"立即安装", "下载安装", "去安装", "安装应用",
            "立即下载", "安全下载", "高速下载", "继续安装"};

    private static String clickPositive(View v, int depth) {
        if (v == null || depth > 30) return null;
        try {
            if (v instanceof TextView) {
                CharSequence cs = ((TextView) v).getText();
                String t = (cs == null) ? null : cs.toString();
                if (t != null && containsAny(t, POSITIVE) && !containsAny(t, NEGATIVE)) {
                    if (v.isShown()) {
                        v.performClick();
                        return t;
                    }
                }
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    String r = clickPositive(g.getChildAt(i), depth + 1);
                    if (r != null) return r;
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
        return null;
    }

    private static String collectText(View v, int depth) {
        if (v == null || depth > 30) return "";
        StringBuilder sb = new StringBuilder();
        try {
            if (v instanceof TextView) {
                CharSequence cs = ((TextView) v).getText();
                if (cs != null) sb.append(cs).append(' ');
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    sb.append(collectText(g.getChildAt(i), depth + 1));
                }
            }
        } catch (Throwable t) {
        }
        return sb.toString();
    }

    // ======================================================================
    //  3. WebView
    // ======================================================================
    private static void hookWebView() {
        try {
            Class<?> wv = WebView.class;
            XposedBridge.hookAllMethods(wv, "loadUrl", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        if (param.args == null || param.args.length < 1) return;
                        Object a = param.args[0];
                        if (a == null) return;
                        reload(false);
                        String hit = matchUrl(String.valueOf(a));
                        if (hit != null) {
                            onBlocked(null, "WebView.loadUrl", hit + " @" + a);
                            param.setResult(null);
                        }
                    } catch (Throwable t) {
                        XposedBridge.log(t);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }

    // ======================================================================
    //  4. WindowManager
    // ======================================================================
    private static void hookWindowManager(XC_LoadPackage.LoadPackageParam lp) {
        try {
            Class<?> wmi = XposedHelpers.findClass("android.view.WindowManagerImpl", lp.classLoader);
            XposedHelpers.findAndHookMethod(wmi, "addView", View.class,
                    ViewGroup.LayoutParams.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                View v = (View) param.args[0];
                                if (v == null) return;
                                if (isDecor(v)) return; // 主窗口放行，防黑屏
                                Object o = param.args[1];
                                if (o instanceof WindowManager.LayoutParams) {
                                    int type = ((WindowManager.LayoutParams) o).type;
                                    if (isOverlay(type)) {
                                        onBlocked(null, "addView", "悬浮窗 type=" + type);
                                        param.setResult(null);
                                        return;
                                    }
                                }
                                reload(false);
                                String hit = matchClass(v.getClass().getName());
                                if (hit != null) {
                                    onBlocked(null, "addView", hit + " @" + v.getClass().getName());
                                    param.setResult(null);
                                }
                            } catch (Throwable t) {
                                XposedBridge.log(t);
                            }
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }

    private static boolean isDecor(View v) {
        return v.getClass().getName().contains("DecorView");
    }

    private static boolean isOverlay(int type) {
        return type == 2002 || type == 2003 || type == 2005 || type == 2006
                || type == 2010 || type == 2011 || type == 2015 || type == 2016
                || type == 2038 || type == 2040;
    }

    // ======================================================================
    //  规则引擎
    // ======================================================================
    private static void ensureRulesFile() {
        try {
            File f = new File(RULES_PATH);
            if (f.exists()) return;
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(defaultRules().getBytes("UTF-8"));
            fo.close();
        } catch (Throwable t) {
            // 无写权限就算了，内置规则已经足够
        }
    }

    public static String defaultRules() {
        StringBuilder sb = new StringBuilder();
        sb.append("# DuckGuard 拦截规则\n");
        sb.append("# url:xxx  URL 子串 | class:xxx View类名子串 | re:正则\n");
        sb.append("url:market://\nurl:mimarket://\nurl:oppomarket://\nurl:heytapmarket://\n");
        sb.append("url:vivomarket://\nurl:appmarket://\nurl:hiapplink://\nurl:oaps://\n");
        sb.append("url:.apk\nurl:downloadapk\nurl:deeplink\nurl:landing.html\n");
        sb.append("url:pglstatp-toutiao.com\nurl:ad-pattern\nurl:csj-sdk-static\nurl:uchain\n");
        sb.append("url:立即下载\nurl:立即安装\nurl:安全下载\nurl:高速下载\n");
        sb.append("class:download\nclass:install\nclass:apk\nclass:webview\n");
        sb.append("class:deeplink\nclass:landing\nclass:adcontainer\nclass:splashad\n");
        return sb.toString();
    }

    private static void loadBuiltin() {
        S_URL.clear();
        S_CLS.clear();
        S_RE.clear();
        String[] lines = defaultRules().split("\n");
        for (int i = 0; i < lines.length; i++) parseLine(lines[i]);
    }

    private static void parseLine(String raw) {
        if (raw == null) return;
        String s = raw.trim();
        if (s.length() == 0 || s.startsWith("#")) return;
        String low = s.toLowerCase();
        if (low.startsWith("url:")) {
            add(S_URL, s.substring(4));
        } else if (low.startsWith("class:")) {
            add(S_CLS, s.substring(6));
        } else if (low.startsWith("re:")) {
            try {
                S_RE.add(Pattern.compile(s.substring(3), Pattern.CASE_INSENSITIVE));
            } catch (Throwable t) {
            }
        } else {
            add(S_URL, s);
            add(S_CLS, s);
        }
    }

    private static void add(ArrayList<String> l, String s) {
        if (s == null) return;
        String v = s.trim().toLowerCase();
        if (v.length() > 0 && !l.contains(v)) l.add(v);
    }

    private static void reload(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - sLastCheck < 5000L) return;
        sLastCheck = now;
        try {
            File f = new File(RULES_PATH);
            long stamp = f.exists() ? f.lastModified() : -1L;
            if (!force && stamp == sLastStamp) return;
            sLastStamp = stamp;
            loadBuiltin();
            if (f.exists() && f.canRead()) {
                BufferedReader br = new BufferedReader(new FileReader(f));
                String line;
                while ((line = br.readLine()) != null) parseLine(line);
                br.close();
            }
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }

    private static String matchUrl(String url) {
        if (url == null) return null;
        String u = url.toLowerCase();
        if (u.contains("cocos2d")) return null;
        for (int i = 0; i < S_URL.size(); i++) {
            if (u.contains(S_URL.get(i))) return "url:" + S_URL.get(i);
        }
        for (int i = 0; i < S_RE.size(); i++) {
            if (S_RE.get(i).matcher(u).find()) return "re:" + S_RE.get(i).pattern();
        }
        return null;
    }

    private static String matchClass(String cls) {
        if (cls == null) return null;
        String c = cls.toLowerCase();
        if (c.contains("cocos2d")) return null;
        for (int i = 0; i < S_CLS.size(); i++) {
            if (c.contains(S_CLS.get(i))) return "class:" + S_CLS.get(i);
        }
        return null;
    }

    private static boolean containsAny(String t, String[] words) {
        for (int i = 0; i < words.length; i++) {
            if (t.indexOf(words[i]) >= 0) return true;
        }
        return false;
    }

    private static boolean isInstallText(String t) {
        return t != null && containsAny(t, INSTALL_WORDS);
    }

    private static String shortText(String t) {
        if (t == null) return "";
        String s = t.replace('\n', ' ').trim();
        return s.length() > 50 ? s.substring(0, 50) + "..." : s;
    }

    // ======================================================================
    //  上报 / Toast
    // ======================================================================
    private static void onBlocked(Context ctx, String where, String why) {
        String msg = "[DuckGuard] " + where + " | " + why;
        XposedBridge.log(msg);
        stats(where + " | " + why);
        toast(ctx, "已拦截: " + where);
    }

    private static void stats(String line) {
        try {
            FileOutputStream fo = new FileOutputStream(new File(STATS_PATH), true);
            fo.write((System.currentTimeMillis() + " " + line + "\n").getBytes("UTF-8"));
            fo.close();
        } catch (Throwable t) {
        }
    }

    private static void toast(Context ctx, final String msg) {
        final Context c = (ctx != null) ? ctx.getApplicationContext() : app();
        if (c == null) return;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    Toast.makeText(c, "【DuckGuard】" + msg, Toast.LENGTH_SHORT).show();
                } catch (Throwable t) {
                }
            }
        });
    }

    private static Context app() {
        if (sApp != null) return sApp;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Method m = at.getDeclaredMethod("currentApplication");
            m.setAccessible(true);
            Object o = m.invoke(null);
            if (o instanceof Context) sApp = (Context) o;
        } catch (Throwable t) {
        }
        return sApp;
    }
}
