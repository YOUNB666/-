package com.duckguard.xp;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 模块入口。assets/xposed_init 里写的就是这个类名。
 * LSPosed 勾选目标 App 后，目标进程启动时会回调这里。
 */
public class HookEntry implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (lp == null || lp.packageName == null) return;
        // 不 hook 自己
        if ("com.duckguard.xp".equals(lp.packageName)) return;
        // 不 hook 系统进程（容易出问题）
        if (lp.packageName.equals("android")) return;

        XposedBridge.log("[DuckGuard] 注入: " + lp.packageName);
        AdBlocker.install(lp);
    }
}
