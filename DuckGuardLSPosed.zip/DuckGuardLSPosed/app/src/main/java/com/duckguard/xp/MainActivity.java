package com.duckguard.xp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;

/**
 * 模块自带的控制面板：查看状态 / 拦截记录 / 一键写出规则模板。
 * 纯代码建 View，不依赖 layout 和 AppCompat，编译最简单。
 */
public class MainActivity extends Activity {

    private TextView mStatus;
    private TextView mLog;
    private final Handler mHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));
        root.setBackgroundColor(Color.parseColor("#101418"));

        TextView title = new TextView(this);
        title.setText("DuckGuard 广告拦截");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22f);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title);

        mStatus = new TextView(this);
        mStatus.setTextColor(Color.parseColor("#9BE38C"));
        mStatus.setTextSize(13f);
        mStatus.setPadding(0, dp(12), 0, dp(12));
        root.addView(mStatus);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);

        Button bWrite = new Button(this);
        bWrite.setText("写出规则模板");
        bWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeRules();
            }
        });
        bar.addView(bWrite);

        Button bRefresh = new Button(this);
        bRefresh.setText("刷新");
        bRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refresh();
            }
        });
        bar.addView(bRefresh);

        Button bClear = new Button(this);
        bClear.setText("清空记录");
        bClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearStats();
            }
        });
        bar.addView(bClear);

        root.addView(bar);

        ScrollView sc = new ScrollView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        sc.setLayoutParams(lp);

        mLog = new TextView(this);
        mLog.setTextColor(Color.parseColor("#C8D0D8"));
        mLog.setTextSize(12f);
        mLog.setPadding(0, dp(12), 0, 0);
        sc.addView(mLog);
        root.addView(sc);

        setContentView(root);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        StringBuilder sb = new StringBuilder();
        sb.append("状态：模块已安装（需在 LSPosed 里勾选目标 App）\n");
        sb.append("规则：" + AdBlocker.RULES_PATH + "\n");
        File rf = new File(AdBlocker.RULES_PATH);
        sb.append("    存在=" + rf.exists() + "  可读=" + rf.canRead() + "\n");
        sb.append("记录：" + AdBlocker.STATS_PATH + "\n");
        mStatus.setText(sb.toString());

        ArrayList<String> lines = new ArrayList<String>();
        File sf = new File(AdBlocker.STATS_PATH);
        if (sf.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(sf));
                String line;
                while ((line = br.readLine()) != null) lines.add(line);
                br.close();
            } catch (Throwable t) {
            }
        }

        StringBuilder out = new StringBuilder();
        out.append("拦截次数：" + lines.size() + "\n");
        out.append("-----------------------------\n");
        int start = Math.max(0, lines.size() - 40);
        for (int i = start; i < lines.size(); i++) {
            out.append(lines.get(i)).append('\n');
        }
        if (lines.isEmpty()) {
            out.append("(还没有拦截记录)\n");
            out.append("\n使用方法：\n");
            out.append("1. 在 LSPosed 里启用「DuckGuard 广告拦截」\n");
            out.append("2. 作用域勾选你要治的 App\n");
            out.append("3. 强制停止并重开目标 App\n");
            out.append("4. 回到这里点「刷新」看拦截记录\n");
        }
        mLog.setText(out.toString());
    }

    private void writeRules() {
        try {
            File f = new File(AdBlocker.RULES_PATH);
            FileOutputStream fo = new FileOutputStream(f, false);
            fo.write(AdBlocker.defaultRules().getBytes("UTF-8"));
            fo.close();
            toast("已写出: " + AdBlocker.RULES_PATH);
        } catch (Throwable t) {
            toast("写入失败（需要 /data/local/tmp 写权限）: " + t);
        }
        refresh();
    }

    private void clearStats() {
        try {
            FileOutputStream fo = new FileOutputStream(new File(AdBlocker.STATS_PATH), false);
            fo.write(new byte[0]);
            fo.close();
            toast("已清空");
        } catch (Throwable t) {
            toast("清空失败: " + t);
        }
        refresh();
    }

    private void toast(final String s) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show();
            }
        });
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
